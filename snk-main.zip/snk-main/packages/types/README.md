# @snk/types

set of basic types and helpers
