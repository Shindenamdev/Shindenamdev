# @snk/svg-creator

Generate a svg file from the grid and snake path.

Use css style tag to animate the snake and the grid cells. For that reason it only work in browser. Animations are likely to be ignored be native image reader.
